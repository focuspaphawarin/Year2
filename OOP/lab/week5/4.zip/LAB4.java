package OOP.LAB.week5;

import java.util.Scanner;

public class LAB4 
{
    public static void main(String[] args)
    {
        Scanner SC = new Scanner(System.in);
        int m=SC.nextInt(),n=SC.nextInt(),w=SC.nextInt();
        KIB K = new KIB(m,n,w);
    }
}
