public class Date 
{
    int d,m,y;
    Date(){}
    public Date(int d,int m,int y)
    {
        this.d=d;
        this.m=m;
        this.y=y;
    }

}
