public class Point 
{
    double x,y;
    Point()
    {
        this.x = 0;
        this.y = 0;
    }
    Point(double xp, double yp)
    {
        this.x = xp;
        this.y = yp;
    }
}
